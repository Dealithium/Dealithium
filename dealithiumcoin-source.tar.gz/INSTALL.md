Building Dealithiumcoin
================

See doc/build-*.md for instructions on building the various
elements of the Dealithiumcoin Core reference implementation of Dealithiumcoin.
